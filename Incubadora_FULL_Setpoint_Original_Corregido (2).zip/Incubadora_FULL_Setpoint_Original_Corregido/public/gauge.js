/* gauge.js - Indicador analógico (aguja) en SVG con zonas normal / advertencia / crítica.
   La aguja es negra con borde blanco: se ve igual sobre fondo claro, oscuro o sobre las zonas de color.
   Uso: const poner = crearGauge(elementoHTML, CONFIG.nivel);  poner(72.4);
   Opción { compacto: true } -> versión baja y sin texto, para paneles con poco espacio. */

function crearGauge(contenedor, cfg, { compacto = false } = {}) {
  const cx = 120, cy = 120, r = 88;
  const ang = (v) => Math.PI * (1 - (v - cfg.min) / (cfg.max - cfg.min));
  const pt = (v, rad) => [cx + rad * Math.cos(ang(v)), cy - rad * Math.sin(ang(v))];
  const arco = (a, b, color) => {
    const p = pt(a, r), q = pt(b, r);
    return `<path d="M${p[0]} ${p[1]} A${r} ${r} 0 0 1 ${q[0]} ${q[1]}" fill="none" stroke="${color}" stroke-width="16"/>`;
  };

  let marcas = '';
  const paso = (cfg.max - cfg.min) / 5;
  for (let i = 0; i <= 5; i++) {
    const v = cfg.min + i * paso;
    const a = pt(v, r - 11), b = pt(v, r - 19), t = pt(v, r - 31);
    marcas += `<line x1="${a[0]}" y1="${a[1]}" x2="${b[0]}" y2="${b[1]}" stroke="var(--txt2)" stroke-width="1.5"/>
               <text x="${t[0]}" y="${t[1] + 4}" text-anchor="middle" font-size="11" fill="var(--txt2)">${Math.round(v)}</text>`;
  }

  contenedor.innerHTML = `
    <svg viewBox="0 0 240 ${compacto ? 136 : 160}" role="img" aria-label="Indicador analógico de ${cfg.nombre}">
      <path d="M16 120 A104 104 0 0 1 224 120 Z" fill="var(--bg)"/>
      ${arco(cfg.min, cfg.adv, 'var(--ok)')}
      ${arco(cfg.adv, cfg.crit, 'var(--adv)')}
      ${arco(cfg.crit, cfg.max, 'var(--crit)')}
      ${marcas}
      <g class="aguja" style="transform:rotate(-90deg)">
        <polygon points="113,124 127,124 120,26" fill="#111" stroke="#fff" stroke-width="2" stroke-linejoin="round"/>
      </g>
      <circle cx="120" cy="120" r="10" fill="#111" stroke="#fff" stroke-width="2.5"/>
      ${compacto ? '' : '<text class="gv" x="120" y="152" text-anchor="middle" font-size="16" font-weight="600" fill="var(--txt)">--</text>'}
    </svg>`;

  const aguja = contenedor.querySelector('.aguja');
  const texto = contenedor.querySelector('.gv');
  return (v) => {
    const frac = clamp((v - cfg.min) / (cfg.max - cfg.min), 0, 1);
    aguja.style.transform = `rotate(${-90 + 180 * frac}deg)`;
    if (texto) texto.textContent = v.toFixed(1) + ' ' + cfg.unidad;
  };
}
