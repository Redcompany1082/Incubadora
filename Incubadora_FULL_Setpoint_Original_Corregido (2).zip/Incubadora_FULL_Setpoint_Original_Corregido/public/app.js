'use strict';
const $=id=>document.getElementById(id);
const clamp=(v,a,b)=>Math.min(b,Math.max(a,v));
const cssVar=name=>getComputedStyle(document.documentElement).getPropertyValue(name).trim();
const hora=ts=>new Date(ts).toLocaleTimeString('es-SV',{hour12:false});
const fmt=(n,dec=1)=>typeof n==='number'&&Number.isFinite(n)?n.toFixed(dec):'—';
let records=[],liveBuffer=[],events=[],rangeMin=30,customQuery=null;
let liveTemp=null,livePower=null,histChart=null,lastHistDraw=0;
const tempGauge=crearGauge($('tempGauge'),{nombre:'Temperatura',unidad:'°C',min:20,max:65,adv:55,crit:60},{compacto:true});
const powerGauge=crearGauge($('powerGauge'),{nombre:'Mando',unidad:'%',min:0,max:100,adv:60,crit:90},{compacto:true});
function setLed(id,state){$(id).className='led '+(state||'');}
function base(label,color,axis='y'){
  return {label,data:[],borderColor:cssVar(color),pointRadius:0,borderWidth:2.3,tension:0.2,spanGaps:true,yAxisID:axis};
}
function lineChart(id,datasets,yTitle,min,max){
  return new Chart($(id),{type:'line',data:{labels:[],datasets},options:{responsive:true,maintainAspectRatio:false,animation:false,interaction:{mode:'index',intersect:false},scales:{x:{ticks:{maxTicksLimit:8,maxRotation:0}},y:{min,max,title:{display:true,text:yTitle}}},plugins:{legend:{display:true,position:'top',align:'end',labels:{boxWidth:12}}}}});
}
function graphsInit(){
  if(typeof Chart==='undefined'){
    $('tempFallback').hidden=false;$('powerFallback').hidden=false;$('histFallback').hidden=false;
    return;
  }
  Chart.defaults.color=cssVar('--txt2'); Chart.defaults.borderColor=cssVar('--line'); Chart.defaults.font.size=11;
  liveTemp=lineChart('tempChart',[base('LM35 (°C)','--acc'),{...base('Setpoint (°C)','--adv'),borderDash:[6,4],borderWidth:1.5}],'°C');
  livePower=lineChart('powerChart',[base('Mando solicitado (%)','--acc2')],'%',0,100);
  histChart=new Chart($('historyChart'),{type:'line',data:{labels:[],datasets:[
    base('LM35 (°C)','--acc','t'),
    {...base('Setpoint (°C)','--adv','t'),borderDash:[6,4],borderWidth:1.5},
    base('Mando (%)','--acc2','p')
  ]},options:{responsive:true,maintainAspectRatio:false,animation:false,interaction:{mode:'index',intersect:false},scales:{
    x:{ticks:{maxTicksLimit:8,maxRotation:0}},
    t:{type:'linear',position:'left',title:{display:true,text:'°C'}},
    p:{type:'linear',position:'right',min:0,max:100,title:{display:true,text:'Mando (%)'},grid:{drawOnChartArea:false}}
  },plugins:{legend:{position:'top',labels:{boxWidth:12}}}}});
}
function updateLive(){
  if(!liveTemp||!livePower)return;
  const sub=liveBuffer.slice(-90),labels=sub.map(m=>hora(m.ts));
  liveTemp.data.labels=labels; liveTemp.data.datasets[0].data=sub.map(m=>m.pv); liveTemp.data.datasets[1].data=sub.map(m=>m.sp);liveTemp.update('none');
  livePower.data.labels=labels;livePower.data.datasets[0].data=sub.map(m=>m.mando);livePower.update('none');
  if(!customQuery && Date.now()-lastHistDraw>3000)drawHistory();
}
function drawHistory(){
  if(!histChart)return;
  lastHistDraw=Date.now();
  const sub=customQuery?records:records.filter(m=>m.ts>=Date.now()-rangeMin*60_000);
  const stride=Math.max(1,Math.ceil(sub.length/720));
  const series=sub.filter((_,i)=>i%stride===0);
  histChart.data.labels=series.map(m=>hora(m.ts));
  histChart.data.datasets[0].data=series.map(m=>m.pv);
  histChart.data.datasets[1].data=series.map(m=>m.sp);
  histChart.data.datasets[2].data=series.map(m=>m.mando);
  const show=[$('showTemp').checked,$('showSp').checked,$('showPower').checked];
  histChart.data.datasets.forEach((d,i)=>d.hidden=!show[i]);
  histChart.options.scales.t.display=show[0]||show[1];
  histChart.options.scales.p.display=show[2];
  histChart.update('none');
}
function updateUI(m){
  $('tempValue').textContent=fmt(m.pv,2);
  $('readingTime').textContent=hora(m.ts);
  $('commandValue').textContent=fmt(m.mando,1);
  $('spValue').textContent=fmt(m.sp,1)+' °C';
  $('errorValue').textContent=fmt(m.error_c,2)+' °C';
  $('lcdValue').textContent=fmt(m.pv_lcd,2)+' °C';
  $('modeText').textContent=m.modo==='MAN'?'MANUAL':'AUTOMÁTICO';
  $('modeBadge').textContent=m.modo==='MAN'?'Manual':'Automático';
  $('powerValue').textContent=fmt(m.mando,1)+' %';
  $('powerFill').style.width=clamp(Number(m.mando)||0,0,100)+'%';
  const alarm=!!m.alarma;
  const alerta= !alarm && Number(m.sp) < Number(m.pv) - 1.0;
  $('tempBadge').className='badge '+(alarm?'critica':alerta?'advertencia':'normal');
  $('tempBadge').textContent=alarm?'Fallo crítico':alerta?'Sobre la consigna':'Lectura LM35';
  $('powerBadge').className='badge '+(m.ac_habilitada?'advertencia':'info');
  $('powerBadge').textContent=m.ac_habilitada?'D9 configurado activo':'D9 deshabilitado';
  const causas={1:'LM35 inválido/desconectado',2:'Salto anómalo LM35',3:'Sobretemperatura crítica',4:'Sincronismo de cruce perdido',5:'Consigna incompatible con calefactor habilitado'};
  $('alarmText').textContent=alarm?(causas[m.alarma_codigo]||'Alarma sin código de causa'):alerta?'Temperatura sobre setpoint':'Sin alarma crítica';
  setLed('alarmLed',alarm?'critica':alerta?'advertencia':'normal');setLed('lmLed',alarm?'critica':'normal');
  setLed('zcLed',m.sincronizado?'normal':'');setLed('acLed',m.ac_habilitada?'advertencia':'');
  $('acText').textContent=m.ac_habilitada?'D9 habilitado en firmware':'D9 deshabilitado en firmware';
  tempGauge(typeof m.pv==='number'?m.pv:20);
  powerGauge(typeof m.mando==='number'?m.mando:0);
  $('sourcePill').textContent='ARDUINO REAL / USB';
}
function showEvents(){
  $('countEvents').textContent=events.length+' eventos';
  $('eventRows').replaceChildren();
  if(!events.length){const tr=document.createElement('tr'),td=document.createElement('td');td.colSpan=4;td.className='vacio';td.textContent='Sin eventos registrados';tr.append(td);$('eventRows').append(tr);return;}
  for(const ev of events.slice(-60).reverse()){
    const tr=document.createElement('tr');tr.className=ev.prioridad;
    for(const value of [hora(ev.ts),ev.origen,ev.descripcion,ev.prioridad]){
      const td=document.createElement('td');td.textContent=value;tr.append(td);
    }
    $('eventRows').append(tr);
  }
}
function pushReading(m){
  liveBuffer.push(m);if(liveBuffer.length>120)liveBuffer.shift();
  if(!customQuery){records.push(m);if(records.length>7200)records.shift();}
  updateUI(m);updateLive();
}
async function init(){
  graphsInit();
  try{
    const [status,history,evs]=await Promise.all([
      fetch('/api/state').then(r=>r.json()),
      fetch('/api/history?minutes=120').then(r=>r.json()),
      fetch('/api/events').then(r=>r.json())
    ]);
    records=history;liveBuffer=history.slice(-120);events=evs.reverse();showEvents();if(status.latest)updateUI(status.latest);updateStateInfo(status);updateLive();drawHistory();
  }catch(err){console.error('Inicio:',err);}
  connect();
}
function connect(){
  const ws=new WebSocket(`${location.protocol==='https:'?'wss':'ws'}://${location.host}/ws`);
  ws.onopen=()=>{setLed('connLed','normal');$('connText').textContent='WebSocket conectado';};
  ws.onclose=()=>{setLed('connLed','advertencia');$('connText').textContent='Sin conexión al servidor';setTimeout(connect,2500);};
  ws.onmessage=event=>{
    try{
      const msg=JSON.parse(event.data);
      if(msg.type==='reading')pushReading(msg.data);
      if(msg.type==='event'){events.push(msg.data);if(events.length>500)events.shift();showEvents();}
      if(msg.type==='connection'&&!msg.data.connected){$('connText').textContent='Arduino desconectado';setLed('connLed','advertencia');}
    }catch(e){console.error(e);}
  };
}
$('ranges').addEventListener('click',async e=>{
  const b=e.target.closest('button[data-min]');if(!b)return;
  rangeMin=Number(b.dataset.min);customQuery=null;
  for(const n of document.querySelectorAll('#ranges button'))n.classList.toggle('activo',n===b);
  try{
    const response=await fetch(`/api/history?minutes=${rangeMin}`);
    if(!response.ok)throw Error('Error consultando MySQL');
    records=await response.json();$('histMsg').textContent='Histórico cargado desde MySQL';
  }catch(err){$('histMsg').textContent=err.message;}
  updateLive();drawHistory();
});
$('showTemp').addEventListener('change',drawHistory);
$('showSp').addEventListener('change',drawHistory);
$('showPower').addEventListener('change',drawHistory);
$('exportCsv').addEventListener('click',()=>{
  location.href='/api/export.csv?'+(customQuery||`minutes=${rangeMin}`);
});
$('histApply').addEventListener('click',async()=>{
  const s=$('histStart').value,e=$('histEnd').value;
  if(!s||!e){$('histMsg').textContent='Selecciona fecha/hora inicial y final';return;}
  const start=new Date(s),end=new Date(e);
  if(!Number.isFinite(start.getTime())||!Number.isFinite(end.getTime())||end<start){$('histMsg').textContent='Rango inválido';return;}
  const params=new URLSearchParams({start:start.toISOString(),end:end.toISOString()});
  try{
    const r=await fetch('/api/history?'+params);
    const d=await r.json();if(!r.ok)throw Error(d.error||'Error de MySQL');
    customQuery=params.toString();records=d;
    document.querySelectorAll('#ranges button').forEach(n=>n.classList.remove('activo'));
    $('histMsg').textContent=`${d.length} lecturas recuperadas de MySQL`;
    drawHistory();
  }catch(err){$('histMsg').textContent=err.message;}
});
let lastRemoteReason='';
function updateStateInfo(state){
  const sql=state.sql||{};
  const b=$('sqlBadge');
  if(!sql.enabled){b.textContent='MySQL DESACTIVADO';b.className='badge info';}
  else if(sql.guardando){b.textContent='MySQL GUARDANDO';b.className='badge normal';}
  else if(sql.connected){b.textContent='MySQL CONECTADO · sin escritura reciente';b.className='badge advertencia';}
  else{b.textContent='MySQL ERROR';b.className='badge critica';}
  b.title=sql.lastError|| (sql.lastWrite?'Última inserción: '+new Date(sql.lastWrite).toLocaleTimeString('es-SV'):'Sin inserciones confirmadas');
  const rem=state.remote||{};
  const ready=!!rem.ready;
  for(const id of ['spRemoto','pinRemoto','submitSp'])$(id).disabled=!ready;
  $('remoteState').textContent=ready?'Arduino disponible':'Bloqueado';
  if(Number.isFinite(rem.min))$('spRemoto').min=rem.min;
  if(Number.isFinite(rem.max))$('spRemoto').max=rem.max;
  if(lastRemoteReason!==rem.reason){$('remoteMessage').textContent=rem.reason||'Sin estado de control remoto';lastRemoteReason=rem.reason;}
  if(state.latest && document.activeElement!==$('spRemoto'))$('spRemoto').value=Number(state.latest.sp).toFixed(1);
}
async function refreshState(){try{updateStateInfo(await fetch('/api/state').then(r=>r.json()));}catch(e){$('sqlBadge').textContent='Servidor sin respuesta';$('sqlBadge').className='badge critica';}}
$('formSp').addEventListener('submit',async e=>{
  e.preventDefault();const sp=Number($('spRemoto').value),pin=$('pinRemoto').value;
  const btn=$('submitSp');btn.disabled=true;
  $('remoteMessage').textContent='Enviando al servidor y esperando confirmación del Arduino…';
  try{
    const res=await fetch('/api/control/setpoint',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({sp,pin})});
    const body=await res.json();
    if(!res.ok)throw new Error(body.error||'No se pudo aplicar el setpoint');
    $('remoteMessage').textContent=`Arduino confirmó el setpoint real: ${body.sp.toFixed(1)} °C`; 
  }catch(err){$('remoteMessage').textContent=`Error: ${err.message}`;}
  finally{$('pinRemoto').value='';await refreshState();}
});
setInterval(refreshState,5000);
init();
