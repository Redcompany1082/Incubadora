-- Esquema de instalación nueva. Servidor Node.js también migra tablas antiguas.
-- Timestamps DATETIME(3) en UTC capturados por el reloj de la computadora.
CREATE DATABASE IF NOT EXISTS incubadora_industria4
  CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE incubadora_industria4;
CREATE TABLE IF NOT EXISTS lecturas (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  fecha DATETIME(3) NOT NULL,
  temp_lm35_c DOUBLE NULL,
  temp_lcd_c DOUBLE NULL,
  setpoint_c DOUBLE NULL,
  error_c DOUBLE NULL,
  modo VARCHAR(8) NOT NULL,
  mando_solicitado_pct DOUBLE NULL,
  alarma TINYINT(1) NOT NULL DEFAULT 0,
  alarma_codigo TINYINT UNSIGNED NULL,
  aviso_codigo TINYINT UNSIGNED NULL,
  ac_configurada TINYINT(1) NOT NULL DEFAULT 0,
  sincronizado TINYINT(1) NULL,
  adc DOUBLE NULL,
  t_ms BIGINT UNSIGNED NULL,
  fuente VARCHAR(12) NOT NULL DEFAULT 'ARDUINO',
  INDEX idx_lecturas_fecha(fecha)
) ENGINE=InnoDB;
CREATE TABLE IF NOT EXISTS eventos_alarmas (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  fecha DATETIME(3) NOT NULL,
  prioridad VARCHAR(14) NOT NULL,
  origen VARCHAR(30) NOT NULL,
  descripcion VARCHAR(250) NOT NULL,
  reconocido TINYINT(1) NOT NULL DEFAULT 0,
  codigo TINYINT UNSIGNED NULL,
  INDEX idx_eventos_fecha(fecha)
) ENGINE=InnoDB;
CREATE TABLE IF NOT EXISTS comandos_setpoint (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  fecha_solicitud DATETIME(3) NOT NULL,
  fecha_confirmacion DATETIME(3) NULL,
  consigna_solicitada_c DOUBLE NOT NULL,
  consigna_confirmada_c DOUBLE NULL,
  estado VARCHAR(20) NOT NULL,
  detalle VARCHAR(250) NULL,
  origen VARCHAR(25) NOT NULL DEFAULT 'WEB',
  INDEX idx_comandos_fecha(fecha_solicitud)
) ENGINE=InnoDB;
