-- Ejecutar desde la consola mysql> como administrador.
-- Crear usuario independiente de la cuenta root.
-- REEMPLAZA las contrasenas por valores fuertes en tu PC.
CREATE DATABASE IF NOT EXISTS incubadora_industria4
  CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- Para un usuario nuevo, descomenta y asigna una contrasena propia.
-- CREATE USER 'incubadora_app'@'127.0.0.1' IDENTIFIED BY 'CONTRASENA_FUERTE_AQUI';
-- GRANT SELECT, INSERT, UPDATE, CREATE, ALTER, INDEX ON incubadora_industria4.* TO 'incubadora_app'@'127.0.0.1';
-- FLUSH PRIVILEGES;

-- Node.js crea/actualiza las tablas al iniciar.
