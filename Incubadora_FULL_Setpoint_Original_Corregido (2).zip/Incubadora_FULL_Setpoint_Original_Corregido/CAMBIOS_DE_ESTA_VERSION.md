# Corrección conservando la configuración original

- Sin cambio de ganancias: Kp=2.0, Ki=0.05, Kd=0.
- Sin cambio de SP inicial: 50.0 °C.
- Sin cambio del rango de SP: 25.0–55.0 °C en pruebas con D9 deshabilitado.
- Eliminada la línea que forzaba SP=37.5 °C en `setup()`.
- PI continuo: no se añadió apagado al cruzar el SP.
- Se añadió alarma código 5 si se intenta activar AC con SP fuera de 36–38 °C; se conserva el corte 38.5 °C cuando AC está habilitada.
- Se agregó `PID_OUT` en el registro serial sin romper el parser existente.
- Actualizados los textos de alarma código 5 de Node.js y dashboard.
- Sin cambios de MySQL ni del PIN actual.

**D9 sigue deshabilitado por defecto.** No usar 120 V sin corregir la etapa y comprobar un corte térmico independiente. En pruebas con D9 deshabilitado, el corte original de 60 °C no constituye un umbral seguro de incubación.
