'use strict';
const {test}=require('node:test');
const assert=require('node:assert/strict');
const {isoDb,fromDb}=require('../db');
test('timestamp SQL registra UTC y recupera el mismo instante',()=>{
  const ts=Date.parse('2026-11-11T16:15:30.321Z');
  const written=isoDb(ts);
  assert.equal(written,'2026-11-11 16:15:30.321');
  assert.equal(fromDb(written),ts);
});
test('fecha SQL interpretable a hora local sin alterar UTC',()=>{
  assert.equal(new Date(fromDb('2026-11-11 16:00:00.000')).toISOString(),'2026-11-11T16:00:00.000Z');
});
