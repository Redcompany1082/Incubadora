const test=require('node:test');
const assert=require('node:assert/strict');
const {parseSerial}=require('../parser');
test('LM35, PI y alarmas sin DHT11',()=>{
  const m=parseSerial('t_ms=12000;ADC=348;PV_LCD=37.51;PV=37.56;SP=50.0;MODO=AUTO;MANDO=12.0;SYNC=0;ALARMA=0;AC_HABILITADA=0',100);
  assert.equal(m.pv,37.56);
  assert.equal(m.sp,50);
  assert.ok(Math.abs(m.error_c-12.44)<1e-10);
  assert.equal(m.mando,12);
  assert.equal(m.ac_habilitada,false);
  assert.equal(m.ts,100);
  assert.ok(!('humedad' in m));
});
test('modo manual y alarma',()=>{
  const m=parseSerial('t_ms=1000;PV=36.00;SP=50;MODO=MAN;MANDO=0;ALARMA=1');
  assert.equal(m.modo,'MAN');assert.equal(m.alarma,true);
});
test('ignora encabezados',()=>assert.equal(parseSerial('INICIANDO...'),null));
test('rechaza temperatura no numerica',()=>assert.equal(parseSerial('t_ms=1000;PV=NA'),null));


test('interpreta la causa exacta de una alarma nueva',()=>{
  const m=parseSerial('t_ms=1000;PV=42.60;SP=37.5;MODO=AUTO;MANDO=0;ALARMA=1;ALM_CODIGO=2;AVISO_CODIGO=0;AC_HABILITADA=0');
  assert.equal(m.alarma,true);
  assert.equal(m.alarma_codigo,2);
  assert.equal(m.aviso_codigo,0);
});
test('firmware viejo sin codigo de alarma permanece compatible',()=>{
  const m=parseSerial('t_ms=1000;PV=40.0;SP=37.5;ALARMA=1');
  assert.equal(m.alarma_codigo,null);
});
