# Incubadora Industria 4.0 — FULL REAL (LM35 + USB + Node.js + MySQL)

**Esta versión no tiene modo DEMO.** Siempre espera telemetría de un **Arduino UNO real** por USB y **MySQL real**. El servidor corre en la PC; el teléfono es un navegador en la misma red local. Se toma como base el dashboard `FULL` que compartiste.

## Qué hace ya el proyecto

- Recibe cada segundo temperatura LM35, PV de LCD, setpoint, AUTO/MAN, mando solicitado del PI, sincronismo y códigos de alarma.
- Guarda cada lectura en MySQL, con `fecha` del **reloj de la PC**. MySQL almacena UTC (en `DATETIME(3)`); la web lo convierte a la hora local del navegador. Por ejemplo, El Salvador es UTC-6.
- Permite cambiar SP desde la PC o celular. Node.js escribe `SP:NN.N` a Arduino, recibe `SP_ACK`, guarda la orden (tabla `comandos_setpoint`) y registra el evento. Si Arduino está en MANUAL o en alarma, la solicitud se rechaza. El PIN nunca se guarda en MySQL.
- Indica claramente sobretemperatura, fallo/ruido LM35, pérdida de sincronismo y desconexión USB. Guarda eventos y alarmas.
- Ofrece gráficas de PV/SP y mando, indicadores FULL, históricos de 10 min, 30 min, 1 h, 2 h, fechas y horas personalizadas, y exportación CSV.
- Incluye Chart.js local: después de `npm install` las gráficas no requieren conexión a Internet.

## Seguridad crítica — etapa de potencia pendiente

En ensayos anteriores el bombillo permaneció encendido a temperatura elevada; el gabinete es de madera y el circuito funciona con 120 V. **Hasta que personal competente corrija/verifique el circuito y un corte térmico independiente que interrumpa físicamente la alimentación, NO conectes el calefactor.** Esta entrega mantiene `HABILITAR_SALIDA_AC=false`; la adquisición, el mando PI calculado, MySQL y los comandos de SP son reales, pero el calefactor **no recibe pulsos de D9**. La salida deshabilitada por software no demuestra que el TRIAC desconecte la lámpara: mantener los **120 V físicamente desconectados** para pruebas.

Se conservaron las ganancias y las consignas del firmware anterior (`KP=2`, `KI=0.05`, `KD=0`, SP inicial de ensayo 50 °C; rango 25–55 °C; límite SW 60 °C en modo sin calefactor), como habías solicitado en las versiones previas. **No son consignas ni cortes seguros para incubar huevos.** No se fuerza el SP a 37.5 °C: el firmware mantiene el valor original de 50 °C para pruebas por USB **sin calefactor**. Si alguien cambia la configuración para habilitar la etapa AC con un setpoint fuera de 36–38 °C, entra en alarma crítica (código 5) sin generar pulsos D9; los comandos remotos quedan restringidos en ese caso. Si la etapa AC se habilitara después de corregir/verificar el equipo, sigue existiendo corte software de 38.5 °C. Esto **no sustituye** el corte térmico físico ni valida la seguridad del aparato.

**"Mando solicitado (%)" no es potencia eléctrica medida.** Con el TRIAC desactivado, la potencia real del bombillo es cero (salvo fallas/cableado inseguro). Para registrar vatios reales hará falta instrumentación eléctrica aislada y adecuada, instalada por personal competente. La especificación del trabajo pide dos sensores físicos: en este proyecto solo queda LM35; el segundo sensor sigue pendiente.

## 1. MySQL

En la consola MySQL que ya tienes, crea la base:

```sql
CREATE DATABASE IF NOT EXISTS incubadora_industria4;
```

Puedes crear un usuario de servicio (cambia la contraseña de ejemplo):

```sql
CREATE USER 'incubadora_app'@'127.0.0.1' IDENTIFIED BY 'CAMBIAR_A_UNA_CONTRASENA_FUERTE';
GRANT SELECT, INSERT, UPDATE, CREATE, ALTER, INDEX ON incubadora_industria4.* TO 'incubadora_app'@'127.0.0.1';
FLUSH PRIVILEGES;
```

Si ese usuario ya existe, reutilízalo y configura su contraseña actual en `.env`. El servidor crea `lecturas`, `eventos_alarmas`, `comandos_setpoint` y agrega columnas faltantes a instalaciones anteriores. **No borra registros existentes.**

## 2. Preparar Node.js en Windows

Descomprime el ZIP y abre CMD **en la carpeta que contiene `package.json`**.

```bat
npm install
copy .env.example .env
notepad .env
```

En `.env` actualiza:

```dotenv
SERIAL_PORT=COM4
SERIAL_BAUD=9600
WEB_HOST=0.0.0.0
WEB_PORT=3000
MYSQL_HOST=127.0.0.1
MYSQL_PORT=3306
MYSQL_USER=incubadora_app
MYSQL_PASSWORD=TU_CONTRASENA_REAL
MYSQL_DATABASE=incubadora_industria4
REMOTE_SP_PIN=UN_PIN_DE_6_O_MAS_CARACTERES
```

**No compartas el archivo `.env`.** El PIN viaja por HTTP; permite el dashboard solo en Wi-Fi privada de confianza y no abras el puerto 3000 a Internet. En Windows, habilita el acceso a Node.js solo para **redes privadas**.

## 3. Firmware Arduino

En Arduino IDE instala `PID_v1` y `LiquidCrystal_I2C` compatible con `lcd.init()`. Abre:

`arduino/Incubadora_Solo_LM35/Incubadora_Solo_LM35.ino`

Configura **Arduino UNO**, el puerto **COM4** (o el que tengas) y sube el sketch. No necesitas DHT11 ni DHTNEW. Para configurar la referencia interna de 1.1 V se usa `analogReference(INTERNAL)`, y se promedian 32 lecturas del LM35. Calibra la referencia con un termómetro independiente antes de confiar en centésimas de grado. La LCD muestra MODO/SP y PV/Mando, sin textos de alarmas; LED rojo = alarma.

**Cierra el Monitor Serie** antes de iniciar Node.js; no pueden usar el mismo puerto simultáneamente.

## 4. Iniciar sistema REAL

```bat
npm start
```

En la computadora: `http://127.0.0.1:3000`.

En el celular, misma Wi-Fi: `http://IP_DE_LA_PC:3000` (la IP la ves con `ipconfig`). La computadora debe permanecer encendida. Si MySQL no está disponible, el servidor **no arranca**, para que no confundas memoria con persistencia. Si COM4 se desconecta, Node.js intenta reconectar y registra la incidencia cuando SQL está operativo.

Estado `MySQL GUARDANDO` = inserciones confirmadas recientemente. `MySQL ERROR` = pérdida de almacenamiento; comprueba la red y el servicio.

## 5. Cambiar setpoint desde FULL

En el panel de Setpoint remoto, introduce la consigna y el PIN configurado. Debe existir telemetría reciente del Arduino, MySQL en funcionamiento, AUTO y ninguna alarma enclavada. Pulsa **Enviar setpoint a Arduino**. La PC envía `SP:37.5`, Arduino responde `SP_ACK=37.5`, y la página muestra la confirmación. También se crea un registro en `comandos_setpoint`. Los botones físicos siguen funcionando.

No hay ningún comando web para activar el TRIAC ni para ignorar alarmas.

## 6. Verificar los registros desde MySQL

```sql
USE incubadora_industria4;
SELECT COUNT(*) AS registros FROM lecturas;
SELECT id,fecha,temp_lm35_c,setpoint_c,mando_solicitado_pct,modo,alarma,alarma_codigo
  FROM lecturas ORDER BY id DESC LIMIT 10;
SELECT fecha,prioridad,origen,descripcion,codigo
  FROM eventos_alarmas ORDER BY id DESC LIMIT 20;
SELECT fecha_solicitud,fecha_confirmacion,consigna_solicitada_c,consigna_confirmada_c,estado
  FROM comandos_setpoint ORDER BY id DESC LIMIT 10;
```

La columna `fecha` es **UTC**. En el celular/PC el horario se muestra en su zona local. Si quieres verla directamente en El Salvador en SQL: `SELECT DATE_SUB(fecha, INTERVAL 6 HOUR) AS hora_sv, temp_lm35_c FROM lecturas ORDER BY id DESC LIMIT 10;`.

Para comprobar persistencia, ejecuta `SELECT COUNT(*)` dos veces con 10 segundos de diferencia mientras Arduino envía lecturas. Debe aumentar, aproximadamente una fila por segundo si no hay errores.

## 7. Pruebas y límites

```bat
npm test
```

El código JS pasó verificaciones de sintaxis y las pruebas de parser. **No se ha validado aquí con tu COM4, tu MySQL ni el circuito eléctrico**; esa comprobación solo se puede hacer en tu PC. La plataforma no puede certificar la seguridad térmica o eléctrica de una incubadora de madera con bombillo de 120 V.

El dashboard sigue basado en FULL; la etapa PI aún necesita validar sintonización y anti-windup para eliminar el sobreimpulso medido. **No introducir huevos ni alimentar la etapa de potencia hasta superar la revisión de seguridad.**


## Corrección específica: setpoint original y PI continuo

- El firmware no sustituye automáticamente `Setpoint=50.0` por `37.5` durante `setup()`.
- Los botones y los comandos USB `SP:xx.x` siguen permitiendo `25.0–55.0 °C` mientras `HABILITAR_SALIDA_AC=false`.
- El control PI sigue ejecutándose cada segundo en modo AUTO, sin lógica de encendido/apagado al cruzar el SP.
- Si el propio PI calcula 0 % cuando PV supera SP, ese es su resultado normal, **no significa que el programa esté forzando una parada a 37.5 °C**.
- La alarma crítica código 5 protege contra intentar utilizar físicamente la etapa AC con una consigna no apropiada. La seguridad física sigue siendo obligatoria.
- MySQL, el dashboard, los eventos, el puerto COM4 y el cambio remoto de SP continúan como antes.

Si ya tienes el servidor funcionando con MySQL, **no reemplaces tu `.env`** ni borres las tablas. Basta con subir el `.ino` corregido. Para ver la nueva descripción de alarma código 5 en la web, reemplaza también `server.js` y `public/app.js` y reinicia Node.js (`Ctrl+C`, `npm start`).
