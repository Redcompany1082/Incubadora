/*
  Control de temperatura: Arduino UNO + LM35 + PID + LCD 16x2 I2C
  Interfaz: 3 botones (MODE, +, -) y 3 LEDs (AUTO, MAN, ALARMA)
  Dimmer de angulo de fase: cruce por cero en D2, orden de disparo en D9
  Red prevista: 120 V CA, 60 Hz.


  Bibliotecas: PID_v1, LiquidCrystal_I2C (compatible con init()), Wire.
*/

#include <Arduino.h>
#include <Wire.h>
#include <LiquidCrystal_I2C.h>
#include <PID_v1.h>
#include <avr/interrupt.h>

// --------- Pines ---------
const uint8_t PIN_LM35      = A0;
const uint8_t PIN_ZC        = 2;
const uint8_t PIN_MOC       = 9;
const uint8_t PIN_MODE      = 4;
const uint8_t PIN_MAS       = 5;
const uint8_t PIN_MENOS     = 6;
const uint8_t LED_AUTO      = 7;
const uint8_t LED_MANUAL    = 8;
const uint8_t LED_ALARMA    = 10;

// Ajusta 0x27 a 0x3F si tu modulo I2C utiliza esa direccion.
LiquidCrystal_I2C lcd(0x27, 16, 2);

// IMPORTANTE: false = solo diagnostico e interfaz, sin disparos en D9.
const bool HABILITAR_SALIDA_AC = true; // Seguridad: mantener D9 sin disparos durante el diagnostico

// Referencia INTERNA nominal de 1.1 V del Arduino UNO.
// Ajustar el valor real despues de contrastar con un termometro calibrado.
// No conectar una referencia externa a AREF al usar INTERNAL.
const float ADC_VREF = 1.100f;
const uint8_t MUESTRAS_LM35 = 32;
const float ALFA_LCD = 0.18f; // Filtro SOLO para la pantalla, no para el PID
const double SP_MIN = 30.0;
const double SP_MAX = 55.0;
const double CORTE_TEMP_C = 60.0;
const double TEMP_MIN_VALIDA = 5.0;
const double MANDO_MAX = 100.0;  // Escala 0-100% del mando, no potencia real

// Valores iniciales NO sintonizados para la camara real
const double KP = 55;
const double KI = 4.5;
const double KD = 0.5;

double Setpoint = 40.0;
double Input = 0.0;
double Output = 0.0;
PID controlador(&Input, &Output, &Setpoint, KP, KI, KD, DIRECT);

bool modoAutomatico = true;
bool alarmaEnclavada = false;
uint8_t codigoAlarma = 0;
uint8_t codigoAviso = 0;
const uint8_t ALM_SENSOR = 1;
const uint8_t ALM_SALTO_LM35 = 2;
const uint8_t ALM_SOBRETEMP = 3;
const uint8_t ALM_SINCRONISMO = 4;
const float SALTO_CRITICO_C = 3.0f; // Salto de un segundo improbable para el aire
bool primeraLecturaSegura = true;
double temperaturaAnterior = 0.0;
unsigned long inicioPerdidaZC = 0;
char comandoSerial[24];
uint8_t longitudComando = 0;
double mandoManual = 0.0;
double mandoAplicado = 0.0;
uint16_t adcLM35 = 0;
float adcPromedioLM35 = 0.0f;
double temperaturaLCD = 0.0;
bool temperaturaLCDIniciada = false;

// --------- Temporizacion de dimmer ---------
const uint16_t RETARDO_MIN_US = 1300;
const uint16_t RETARDO_MAX_US = 7800;
const uint16_t PULSO_MOC_US = 200;

volatile uint32_t ultimoCruceUs = 0;
volatile uint32_t contadorCruces = 0;
volatile uint32_t contadorPulsos = 0;
volatile uint16_t retardoTicks = RETARDO_MAX_US * 2U;
volatile uint8_t crucesValidos = 0;
volatile uint8_t faseTimer = 0;
volatile bool zcSincronizado = false;
volatile bool disparoPermitido = false;

uint16_t retardoActualUs = RETARDO_MAX_US;

// --------- Botones con antirrebote ---------
struct Boton {
  uint8_t pin;
  bool anterior;
  bool estable;
  unsigned long instanteCambio;

  void iniciar() {
    pinMode(pin, INPUT_PULLUP);
    anterior = digitalRead(pin);
    estable = anterior;
    instanteCambio = millis();
  }

  bool pulsado(unsigned long ahora) {
    bool lectura = digitalRead(pin);
    if (lectura != anterior) instanteCambio = ahora;
    anterior = lectura;

    if ((unsigned long)(ahora - instanteCambio) >= 35UL && lectura != estable) {
      estable = lectura;
      return estable == LOW;
    }
    return false;
  }
};

Boton btnModo = {PIN_MODE, HIGH, HIGH, 0};
Boton btnMas = {PIN_MAS, HIGH, HIGH, 0};
Boton btnMenos = {PIN_MENOS, HIGH, HIGH, 0};

// --------- Interrupcion: cada cruce detectado ---------
void detectarCruce() {
  uint32_t ahora = micros();
  uint32_t intervalo = ahora - ultimoCruceUs;
  if (ultimoCruceUs != 0 && intervalo < 5000UL) return;

  ultimoCruceUs = ahora;
  contadorCruces++;

  TCCR1B = 0;
  PORTB &= ~_BV(PB1);  // D9 = 0
  faseTimer = 0;

  if (intervalo >= 7300UL && intervalo <= 9400UL) {
    if (crucesValidos < 12) crucesValidos++;
    zcSincronizado = (crucesValidos >= 12);
  } else {
    crucesValidos = 0;
    zcSincronizado = false;
  }

  if (!zcSincronizado || !disparoPermitido) return;

  TCNT1 = 0;
  OCR1A = retardoTicks - 1U;
  TIFR1 = _BV(OCF1A);
  faseTimer = 1;
  // Timer1 en CTC, prescaler 8, tick = 0.5 us con UNO de 16 MHz.
  TCCR1B = _BV(WGM12) | _BV(CS11);
}

ISR(TIMER1_COMPA_vect) {
  TCCR1B = 0;
  TCNT1 = 0;

  if (faseTimer == 1 && disparoPermitido) {
    PORTB |= _BV(PB1); // D9 = 1
    contadorPulsos++;
    faseTimer = 2;
    OCR1A = PULSO_MOC_US * 2U - 1U;
    TIFR1 = _BV(OCF1A);
    TCCR1B = _BV(WGM12) | _BV(CS11);
  } else {
    PORTB &= ~_BV(PB1);
    faseTimer = 0;
  }
}

// --------- Medicion y logica de control ---------
double leerTemperatura() {
  // Se descarta la primera conversion tras el intervalo entre muestras.
  analogRead(PIN_LM35);
  unsigned long suma = 0;
  for (uint8_t i = 0; i < MUESTRAS_LM35; i++) {
    suma += (unsigned long)analogRead(PIN_LM35);
  }
  // Importante: NO redondear a entero antes de convertir a grados.
  adcPromedioLM35 = (float)suma / (float)MUESTRAS_LM35;
  adcLM35 = (uint16_t)(adcPromedioLM35 + 0.5f); // Solo telemetria
  return (double)adcPromedioLM35 * (double)ADC_VREF * 100.0 / 1024.0;
}

void actualizarFiltroLCD(double temperatura) {
  if (!temperaturaLCDIniciada) {
    temperaturaLCD = temperatura;
    temperaturaLCDIniciada = true;
  } else {
    temperaturaLCD += ALFA_LCD * (temperatura - temperaturaLCD);
  }
}

void apagarDisparo() {
  noInterrupts();
  disparoPermitido = false;
  TCCR1B = 0;
  faseTimer = 0;
  PORTB &= ~_BV(PB1);
  interrupts();
}

void activarAlarma(uint8_t codigo) {
  if (alarmaEnclavada) return;
  alarmaEnclavada = true;
  codigoAlarma = codigo;
  controlador.SetMode(MANUAL);
  Output = 0;
  mandoManual = 0;
  mandoAplicado = 0;
  apagarDisparo();
  Serial.print(F("# ALM_CODIGO=")); Serial.println(codigoAlarma);
}

// Setpoint remoto: se recibe desde el dashboard real via USB.
// Solo modifica la consigna en AUTO y sin alarma.
// No activa ni modifica por si mismo el estado del TRIAC.
void procesarComandoSerie(char *linea) {
  if (strncmp(linea, "SP:", 3) != 0) {
    Serial.println(F("SP_ERROR=FORMATO")); return;
  }
  char *finalNumero = nullptr;
  double solicitado = strtod(linea + 3, &finalNumero);
  if (finalNumero == linea + 3 || *finalNumero != '\0' || isnan(solicitado) ||
      solicitado < SP_MIN || solicitado > SP_MAX) {
    Serial.println(F("SP_ERROR=RANGO")); return;
  }
  if (alarmaEnclavada || !modoAutomatico) {
    Serial.println(F("SP_ERROR=ESTADO")); return;
  }
  Setpoint = solicitado;
  Serial.print(F("SP_ACK=")); Serial.println(Setpoint, 1);
}

void leerComandosSerie() {
  while (Serial.available() > 0) {
    char c = (char)Serial.read();
    if (c == '\r') continue;
    if (c == '\n') {
      comandoSerial[longitudComando] = '\0';
      if (longitudComando) procesarComandoSerie(comandoSerial);
      longitudComando = 0;
    } else if (longitudComando < sizeof(comandoSerial) - 1) {
      comandoSerial[longitudComando++] = c;
    } else {
      longitudComando = 0;
      Serial.println(F("SP_ERROR=LONGITUD"));
    }
  }
}

void alternarModo() {
  if (alarmaEnclavada) return;
  if (modoAutomatico) {
    // AUTO -> MAN: conservar el ultimo mando para evitar salto.
    mandoManual = constrain(Output, 0.0, HABILITAR_SALIDA_AC ? 100.0 : MANDO_MAX);
    controlador.SetMode(MANUAL);
    modoAutomatico = false;
  } else {
    // MAN -> AUTO: Initialize() de PID_v1 toma Output como
    // estado inicial de la integral para transferencia sin salto.
    Output = constrain(mandoManual, 0.0, MANDO_MAX);
    controlador.SetMode(AUTOMATIC);
    modoAutomatico = true;
  }
}

void procesarBotones(unsigned long ahora) {
  bool modo = btnModo.pulsado(ahora);
  bool mas = btnMas.pulsado(ahora);
  bool menos = btnMenos.pulsado(ahora);

  if (modo) alternarModo();
  if (alarmaEnclavada) return;

  if (mas) {
    if (modoAutomatico) Setpoint = min(SP_MAX, Setpoint + 1.0);
    else mandoManual = min(HABILITAR_SALIDA_AC ? 100.0 : MANDO_MAX, mandoManual + 5.0);
  }
  if (menos) {
    if (modoAutomatico) Setpoint = max(SP_MIN, Setpoint - 1.0);
    else mandoManual = max(0.0, mandoManual - 5.0);
  }
}

void actualizarMando() {
  if (alarmaEnclavada) {
    mandoAplicado = 0;
    apagarDisparo();
    return;
  }

  mandoAplicado = modoAutomatico ? Output : mandoManual;
  mandoAplicado = constrain(mandoAplicado, 0.0, HABILITAR_SALIDA_AC ? 100.0 : MANDO_MAX);

  // Mando 0 % = sin pulsos; 100 % = retardo minimo.
  // No es una medicion de potencia real.
  double fraccion = mandoAplicado / MANDO_MAX;
  retardoActualUs = RETARDO_MAX_US -
    (uint16_t)(fraccion * (RETARDO_MAX_US - RETARDO_MIN_US));

  uint32_t ultimo;
  bool sync;
  noInterrupts();
  ultimo = ultimoCruceUs;
  sync = zcSincronizado;
  interrupts();

  bool vigente = ultimo != 0 &&
    ((uint32_t)(micros() - ultimo) < 30000UL);

  if (!vigente) {
    noInterrupts();
    zcSincronizado = false;
    crucesValidos = 0;
    interrupts();
    sync = false;
  }

  bool permitir = HABILITAR_SALIDA_AC && sync && vigente &&
                  (mandoAplicado >= 1.0);

  noInterrupts();
  retardoTicks = retardoActualUs * 2U;
  disparoPermitido = permitir;
  if (!permitir) {
    TCCR1B = 0;
    faseTimer = 0;
    PORTB &= ~_BV(PB1);
  }
  interrupts();
}

void actualizarLeds() {
  digitalWrite(LED_AUTO, !alarmaEnclavada && modoAutomatico);
  digitalWrite(LED_MANUAL, !alarmaEnclavada && !modoAutomatico);
  digitalWrite(LED_ALARMA, alarmaEnclavada);
}

void limpiarLinea(uint8_t fila) {
  lcd.setCursor(0, fila);
  lcd.print(F("                "));
  lcd.setCursor(0, fila);
}

void actualizarLCD() {
  // Mostrar SIEMPRE modo, setpoint, temperatura y mando.
  // Las alarmas se indican solamente con el LED rojo y por Serial.
  limpiarLinea(0);
  lcd.print(modoAutomatico ? F("AUTO") : F("MAN "));
  lcd.print(F(" SP:"));
  lcd.print(Setpoint, 1);
  lcd.print(F("C"));

  limpiarLinea(1);
  lcd.print(F("PV:"));
  // Ante alarma no ocultar con el filtro un posible aumento de temperatura.
  lcd.print(alarmaEnclavada ? Input : temperaturaLCD, 2);
  lcd.print(F("C P:"));
  lcd.print((int)(mandoAplicado + 0.5));
  lcd.print(F("%"));
}

void imprimirSerial() {
  static uint32_t crucesPrevios = 0;
  static uint32_t pulsosPrevios = 0;
  uint32_t cruces, pulsos;
  bool sync;
  noInterrupts();
  cruces = contadorCruces;
  pulsos = contadorPulsos;
  sync = zcSincronizado;
  interrupts();

  Serial.print(F("t_ms=")); Serial.print(millis());
  Serial.print(F(";ADC=")); Serial.print(adcLM35);
  Serial.print(F(";ADC_PROM=")); Serial.print(adcPromedioLM35, 2);
  Serial.print(F(";PV_LCD=")); Serial.print(temperaturaLCD, 2);
  Serial.print(F(";PV=")); Serial.print(Input, 2);
  Serial.print(F(";SP=")); Serial.print(Setpoint, 1);
  Serial.print(F(";MODO=")); Serial.print(modoAutomatico ? F("AUTO") : F("MAN"));
  Serial.print(F(";MANDO=")); Serial.print(mandoAplicado, 1);
  Serial.print(F(";PID_OUT=")); Serial.print(Output, 1);
  Serial.print(F(";RETARDO_US=")); Serial.print(retardoActualUs);
  Serial.print(F(";ZC_S=")); Serial.print(cruces - crucesPrevios);
  Serial.print(F(";PULSOS_S=")); Serial.print(pulsos - pulsosPrevios);
  Serial.print(F(";SYNC=")); Serial.print(sync ? 1 : 0);
  Serial.print(F(";ALARMA=")); Serial.print(alarmaEnclavada ? 1 : 0);
  Serial.print(F(";ALM_CODIGO=")); Serial.print(codigoAlarma);
  Serial.print(F(";AVISO_CODIGO=")); Serial.print(codigoAviso);
  Serial.print(F(";AC_HABILITADA=")); Serial.println(HABILITAR_SALIDA_AC ? 1 : 0);

  crucesPrevios = cruces;
  pulsosPrevios = pulsos;
}

void setup() {
  pinMode(PIN_ZC, INPUT_PULLUP);
  pinMode(PIN_MOC, OUTPUT);
  digitalWrite(PIN_MOC, LOW);
  pinMode(PIN_LM35, INPUT);
  pinMode(LED_AUTO, OUTPUT);
  pinMode(LED_MANUAL, OUTPUT);
  pinMode(LED_ALARMA, OUTPUT);
  btnModo.iniciar();
  btnMas.iniciar();
  btnMenos.iniciar();

  Serial.begin(9600);
  Wire.begin();
  lcd.init();
  lcd.backlight();
  lcd.setCursor(0, 0);
  lcd.print(F("CONTROL TEMP PID"));
  lcd.setCursor(0, 1);
  lcd.print(F("INICIANDO..."));

  noInterrupts();
  TCCR1A = 0;
  TCCR1B = 0;
  TCNT1 = 0;
  TIMSK1 = _BV(OCIE1A);
  TIFR1 = _BV(OCF1A);
  interrupts();

  // Referencia interna: seleccionar antes de leer A0.
  analogReference(INTERNAL);
  delay(30);
  for (uint8_t i = 0; i < 8; i++) analogRead(PIN_LM35);

  // Setpoint original 50.0 C, ajustable entre SP_MIN y SP_MAX.
  // D9 deshabilitado para pruebas por USB sin alimentacion CA.
  Input = leerTemperatura();
  temperaturaAnterior = Input;
  primeraLecturaSegura = false;
  actualizarFiltroLCD(Input);
  if (Input < TEMP_MIN_VALIDA) {
    activarAlarma(ALM_SENSOR);
  } else if (Input >= (HABILITAR_SALIDA_AC ? 60 : CORTE_TEMP_C)) {
    activarAlarma(ALM_SOBRETEMP);
  } else {
    controlador.SetOutputLimits(0, MANDO_MAX);
    controlador.SetSampleTime(1000);
    controlador.SetMode(AUTOMATIC);
  }
  // Configurar tambien cuando arranca en alarma, para recuperacion
  // solo tras reinicio fisico con temperatura/sensor validos.
  attachInterrupt(digitalPinToInterrupt(PIN_ZC), detectarCruce, RISING);

  Serial.println(F("CONTROL TERMICO | LCD+BOTONES+LED+PID"));
  Serial.println(F("D2=4N35, D9=MOC3021, A0=LM35, LCD=I2C"));
  Serial.println(F("TELEMETRIA: PV=LM35; SP; MODO; MANDO; ALARMA"));
  if (!HABILITAR_SALIDA_AC) {
    Serial.println(F("ETAPA POTENCIA NO HABILITADA: TELEMETRIA REAL POR USB"));
  }
  actualizarMando();
  actualizarLeds();
  actualizarLCD();
}

void loop() {
  static unsigned long ultimaLectura = 0;
  static unsigned long ultimaLCD = 0;
  unsigned long ahora = millis();

  procesarBotones(ahora);
  leerComandosSerie();

  if (ahora - ultimaLectura >= 1000UL) {
    ultimaLectura = ahora;
    Input = leerTemperatura();
    actualizarFiltroLCD(Input); // No modifica Input ni la accion del PI.

    // Alarma enclavada: solo reinicio fisico tras corregir la falla.
    if (Input < TEMP_MIN_VALIDA) {
      activarAlarma(ALM_SENSOR);
    } else if (Input >= (HABILITAR_SALIDA_AC ? 60 : CORTE_TEMP_C)) {
      activarAlarma(ALM_SOBRETEMP);
    } else if (!primeraLecturaSegura &&
               fabs(Input - temperaturaAnterior) > SALTO_CRITICO_C) {
      // No suavizar ni ignorar un salto anomalo: alarma y D9 OFF.
      activarAlarma(ALM_SALTO_LM35);
    }
    temperaturaAnterior = Input;
    primeraLecturaSegura = false;
    // Sobreconsigna: aviso, NO desconecta el PI (control continuo).
    // Si el PI ordena mando=0 tras alcanzar SP es una orden matematica
    // del controlador, NO un corte programado a 37.5 C.
    codigoAviso = (!alarmaEnclavada && Input >= Setpoint + 1.0) ? 1 : 0;

    if (!alarmaEnclavada && modoAutomatico) controlador.Compute();
    imprimirSerial();
  }

  actualizarMando();
  if (HABILITAR_SALIDA_AC && !alarmaEnclavada && mandoAplicado >= 1.0) {
    bool sincronizado;
    uint32_t cruce;
    noInterrupts(); sincronizado = zcSincronizado; cruce = ultimoCruceUs; interrupts();
    if (!sincronizado || cruce == 0 || (uint32_t)(micros() - cruce) > 30000UL) {
      if (inicioPerdidaZC == 0) inicioPerdidaZC = ahora;
      if ((unsigned long)(ahora - inicioPerdidaZC) >= 3000UL)
        activarAlarma(ALM_SINCRONISMO);
    } else inicioPerdidaZC = 0;
  }
  actualizarLeds();

  if (ahora - ultimaLCD >= 350UL) {
    ultimaLCD = ahora;
    actualizarLCD();
  }
}
