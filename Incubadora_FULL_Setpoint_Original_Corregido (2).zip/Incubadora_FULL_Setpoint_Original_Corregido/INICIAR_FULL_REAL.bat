@echo off
cd /d "%~dp0"
node --version
npm start
pause
